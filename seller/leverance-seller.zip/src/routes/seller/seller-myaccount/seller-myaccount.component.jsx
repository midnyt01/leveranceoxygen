import SellerAccount from "../../../component/seller-panel-components/seller-account-component/seller-account.component"
import Topbar from "../../../component/seller-panel-components/seller-topbar/topbar.component"

const SellerMyAccount = () => {
  return (
    <div>
      <Topbar />
      <SellerAccount />
    </div>
  );
};
  
  export default SellerMyAccount;