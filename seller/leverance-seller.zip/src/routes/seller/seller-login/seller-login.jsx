import SellerLoginForm from "../../../component/seller-panel-components/seller-login.component";

const Sellerlogin = () => {
  return (
    <div>
      <SellerLoginForm />
    </div>
  );
};
  
  export default Sellerlogin;