import AdminCreateAccountForm from "../../../component/admin-panel-components/admin-create-account-form/admin-create-account-form.component";


const AdminCreateAccount = () => {
  return (
    <div>
        <AdminCreateAccountForm />
    </div>
  );
};
  
  export default AdminCreateAccount;