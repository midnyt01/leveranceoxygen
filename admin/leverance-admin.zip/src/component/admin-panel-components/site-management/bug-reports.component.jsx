// import ConfirmDelete from "../confirm-delete/confirm-delete";

const Bugreport = () => {

    return (
        <div>
            <div className="container-fluid m-auto">
                <h3>Bug Reports</h3>
            </div>
        </div>
    )
}

export default Bugreport;